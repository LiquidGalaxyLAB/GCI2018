//GET THE CURRENT USER
firebase.auth().onAuthStateChanged(function(user) {
if (user) {
  document.getElementById("login_div").style.display = "none";
  document.getElementById("user_div").style.display = "block";
} else {
  document.getElementById("login_div").style.display = "block";
  document.getElementById("user_div").style.display = "none";
}
});



function login() {
  //VARIABLE DECLARATION AND VALUE GRAB
  var access_mail = document.getElementById('email').value;
  var access_password = document.getElementById('password').value;
  clearInputs();
  //LOG IN WITH FIREBASE SERVICE
  firebase.auth().signInWithEmailAndPassword(access_mail, access_password).catch(function(error) {
  var errorCode = error.code;
  var errorMessage = error.message;
  window.alert("Error: " + errorMessage);
});

}

function logout() {
  firebase.auth().signOut().then(function() {

}).catch(function(error) {
  window.alert("Error");
});
clearInputs();
}

function signUpLanding() {
  document.getElementById("login_div").style.display = "none";
  document.getElementById("signup_div").style.display = "block";
}

function signup() {
  var signUpEmail = document.getElementById('signupemail').value;
  var signUpPassword = document.getElementById('signuppassword').value;
  var signUpConfirm = document.getElementById('signupconfirm').value;
  var length = signUpPassword.length;
  if (length < 6) {
    window.alert("Password must have at least 6 characters!")
  }
  else {
    if (signUpPassword != signUpConfirm) {
      window.alert("Passwords don't match!")
    }
    else {
      window.alert("Signing Up");
      document.getElementById("login_div").style.display = "block";
      document.getElementById("signup_div").style.display = "none";
      clearInputs();
      firebase.auth().createUserWithEmailAndPassword(signUpEmail, signUpPassword).catch(function(error) {
        var errorCode = error.code;
        var errorMessage = error.message;
        if (errorCode = "auth/email-already-in-use") {
          window.alert("This email is already registered! Sign In or use another email to Sign Up.");
        } else {
          window.alert("Error: " + errorMessage);
        }
      });
    }
  }

}

function addCountryLanding() {
  document.getElementById("addcountry_div").style.display = "block";
  document.getElementById("user_div").style.display = "none";
}


function getCountry() {
  var documentIDlower = document.getElementById('searchbox').value;
  var documentID = documentIDlower.toUpperCase();
  var docRef = db.collection("countries").doc(documentID);
  document.getElementById("outputbox").innerHTML = '';
if (documentID == 'ALL') {
  db.collection("countries").get().then(function(querySnapshot) {
    querySnapshot.forEach(function(doc) {
        console.log(doc.id, " => ", doc.data());
        var output = doc.id + " => " + (doc.data().toSource());
        document.getElementById("results_div").style.display = "block";
        document.getElementById("user_div").style.display = "none";
        document.getElementById("outputbox").innerHTML += '<p></p>' + output;
    });
});
} else {
  docRef.get().then(function(doc) {
      if (doc.exists) {
          console.log("Document data:", doc.data());
          var output = doc.id + " => " + (doc.data().toSource());
          document.getElementById("results_div").style.display = "block";
          document.getElementById("user_div").style.display = "none";
          document.getElementById("outputbox").innerHTML += output;
      } else {
          console.log("No such document!");
          document.getElementById("results_div").style.display = "block";
          document.getElementById("user_div").style.display = "none";
          document.getElementById("outputbox").innerHTML = "No such document!";
      }
  }).catch(function(error) {
      console.log("Error getting document:", error);
  });
}
}




function addCountry() {
  var countryName = document.getElementById('Name').value;
  var countryNameUpper = countryName.toUpperCase();
  var countryContinent = document.getElementById('Continent').value;
  var countryPopulation = document.getElementById('Population').value;
db.collection("countries").doc(countryNameUpper).set({
    Name: countryName,
    Continent: countryContinent,
    Population: countryPopulation
})
.then(function(docRef) {
    console.log("Document successfully written!");
    window.alert("Document successfully written! ID: " + countryName);
})
.catch(function(error) {
    console.error("Error writing document: ", error);
    window.alert("Error writing document: " + error);
});
clearInputs();
}



function backToPanel() {
  document.getElementById("addcountry_div").style.display = "none";
  document.getElementById("user_div").style.display = "block";
  document.getElementById("results_div").style.display = "none";
  clearInputs();
}


function clearInputs() {
  document.getElementById("searchbox").value = '';
  document.getElementById("Name").value = '';
  document.getElementById("Continent").value = '';
  document.getElementById("Population").value = '';
}

function backToSignIn() {
  document.getElementById("login_div").style.display = "block"
  document.getElementById("signup_div").style.display = "none"
  document.getElementById("signupemail").value = '';
  document.getElementById("signuppassword").value = '';
  document.getElementById("signupconfirm").value = '';

}
