//GET THE CURRENT USER
firebase.auth().onAuthStateChanged(function(user) {
if (user) {
  document.getElementById("login_div").style.display = "none";
  document.getElementById("user_div").style.display = "block";
} else {
  document.getElementById("login_div").style.display = "block";
  document.getElementById("user_div").style.display = "none";
}
});


function login() {
  //VARIABLE DECLARATION AND VALUE GRAB
  var access_mail = document.getElementById('email').value;
  var access_password = document.getElementById('password').value;

  //LOG IN WITH FIREBASE SERVICE
  firebase.auth().signInWithEmailAndPassword(access_mail, access_password).catch(function(error) {
  var errorCode = error.code;
  var errorMessage = error.message;
  window.alert("Error: " + errorMessage);
});

}

function logout() {
  firebase.auth().signOut().then(function() {

}).catch(function(error) {
  window.alert("Error");
});
}

function signUpLanding() {
  document.getElementById("login_div").style.display = "none";
  document.getElementById("signup_div").style.display = "block";
}

function signup() {
  var signUpEmail = document.getElementById('signupemail').value;
  var signUpPassword = document.getElementById('signuppassword').value;
  var signUpConfirm = document.getElementById('signupconfirm').value;
  var length = signUpPassword.length;
  if (length < 6) {
    window.alert("Password must have at least 6 characters!")
  }
  else {
    if (signUpPassword != signUpConfirm) {
      window.alert("Passwords don't match!")
    }
    else {
      window.alert("Signing Up");
      document.getElementById("login_div").style.display = "block";
      document.getElementById("signup_div").style.display = "none";
      firebase.auth().createUserWithEmailAndPassword(signUpEmail, signUpPassword).catch(function(error) {
        var errorCode = error.code;
        var errorMessage = error.message;
        if (errorCode = "auth/email-already-in-use") {
          window.alert("This email is already registered! Sign In or use another email to Sign Up.");
        } else {
          window.alert("Error: " + errorMessage);
        }
      });
    }
  }

}
