package com.example.android.hapis_questionnaire;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class WantToHelp extends AppCompatActivity implements ValueEventListener {

    LinearLayout john;
    LinearLayout james;
    LinearLayout jane;
    LinearLayout jake;
    LinearLayout jen;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference mRootReference = firebaseDatabase.getReference();
    private DatabaseReference mLocationReference = mRootReference.child("Location");
    private DatabaseReference mCoordinatesReference = mLocationReference.child("country");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_want_to_help);

        john = (LinearLayout) findViewById(R.id.john);
        james = (LinearLayout) findViewById(R.id.james);
        jane = (LinearLayout) findViewById(R.id.jane);
        jake = (LinearLayout) findViewById(R.id.jake);
        jen = (LinearLayout) findViewById(R.id.jen);

        john.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seePerson("13.0238726,77.5485837");
            }
        });

        james.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seePerson("12.97831,77.5686303");
            }
        });

        jane.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seePerson("12.9940261,77.5932902");
            }
        });

        jake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seePerson("12.9936683,77.5538243");
            }
        });

        jen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seePerson("12.9770823,77.5725585");
            }
        });
    }

    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }

    public void seePerson(String coordinates){
        mCoordinatesReference.setValue(coordinates);
    }

    @Override
    protected void onStart(){
        super.onStart();
        mCoordinatesReference.addValueEventListener(this);

    }
}
