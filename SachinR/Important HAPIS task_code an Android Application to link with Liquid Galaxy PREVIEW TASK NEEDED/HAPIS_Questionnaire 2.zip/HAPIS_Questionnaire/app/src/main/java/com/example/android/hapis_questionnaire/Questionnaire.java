package com.example.android.hapis_questionnaire;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Questionnaire extends AppCompatActivity {

    Button submit;
    Button show;
    //public static final String DATABASE_NAME = "mydatabase";
    //SQLiteDatabase mDatabase;
    public static final String MY_PREFS_NAME = "MyPrefsFile";

    RadioGroup rCity;
    RadioGroup rGender;
    RadioGroup rAge;
    RadioGroup rFood;
    RadioGroup rShelter;
    RadioGroup rWater;
    RadioGroup rRead;
    RadioGroup rWrite;
    RadioGroup rClothes;
    RadioGroup rPhone;
    RadioGroup rHurt;
    RadioGroup rJob;
    RadioGroup rJacket;
    RadioGroup rBlankets;
    RadioGroup rBed;

    RadioButton btnCity;
    RadioButton btnGender;
    RadioButton btnAge;
    RadioButton btnFood;
    RadioButton btnShelter;
    RadioButton btnWater;
    RadioButton btnRead;
    RadioButton btnWrite;
    RadioButton btnClothes;
    RadioButton btnPhone;
    RadioButton btnHurt;
    RadioButton btnJob;
    RadioButton btnJacket;
    RadioButton btnBlankets;
    RadioButton btnBed;

    EditText cityText;
    EditText ageText;

    TextView tv1;
    TextView tv2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionnaire);

        //mDatabase = openOrCreateDatabase(DATABASE_NAME, MODE_PRIVATE, null);

        rCity = (RadioGroup) findViewById(R.id.radiogrpcity);
        rGender = (RadioGroup) findViewById(R.id.radiogrpgender);
        rAge = (RadioGroup) findViewById(R.id.radiogrpage);
        rFood = (RadioGroup) findViewById(R.id.radiogrpfood);
        rShelter = (RadioGroup) findViewById(R.id.radiogrpshelter);
        rWater = (RadioGroup) findViewById(R.id.radiogrpwater);
        rRead = (RadioGroup) findViewById(R.id.radiogrpread);
        rWrite = (RadioGroup) findViewById(R.id.radiogrpwrite);
        rClothes = (RadioGroup) findViewById(R.id.radiogrpclothes);
        rPhone = (RadioGroup) findViewById(R.id.radiogrpphone);
        rHurt = (RadioGroup) findViewById(R.id.radiogrphurt);
        rJob = (RadioGroup) findViewById(R.id.radiogrpjob);
        rJacket = (RadioGroup) findViewById(R.id.radiogrpjacket);
        rBlankets = (RadioGroup) findViewById(R.id.radiogrpblankets);
        rBed = (RadioGroup) findViewById(R.id.radiogrpbed);

        cityText = (EditText) findViewById(R.id.othercity_text);
        ageText = (EditText) findViewById(R.id.otherage_text);

        submit = (Button) findViewById(R.id.btnsubmit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitDetails();
                Toast.makeText(Questionnaire.this,"Details submitted!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Questionnaire.this, PieChart.class));
            }
        });

        show = (Button) findViewById(R.id.btnshow);
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDetails();
            }
        });


        tv1 = (TextView) findViewById(R.id.text1);
        tv2 = (TextView) findViewById(R.id.text2);
    }






    /*private void createEmployeeTable() {
        mDatabase.execSQL(
                "CREATE TABLE IF NOT EXISTS qanda (\n" +
                        "    id int NOT NULL CONSTRAINT quanda_pk PRIMARY KEY,\n" +
                        "    city string NOT NULL,\n" +
                        "    gender string NOT NULL,\n" +
                        "    age string NOT NULL,\n" +
                        "    food string NOT NULL,\n" +
                        "    shelter string NOT NULL,\n" +
                        "    joiningdate string NOT NULL,\n" +
                        "    water string NOT NULL,\n" +
                        "    read string NOT NULL,\n" +
                        "    write string NOT NULL,\n" +
                        "    clothes string NOT NULL,\n" +
                        "    phone string NOT NULL,\n" +
                        "    hurt string NOT NULL,\n" +
                        "    job string NOT NULL,\n" +
                        "    jacket string NOT NULL,\n" +
                        "    blankets string NOT NULL,\n" +
                        "    bed string NOT NULL\n" +
                        ");"
        );
    }*/

    public void submitDetails(){
        int selectedCity = rCity.getCheckedRadioButtonId();
        int selectedGender = rGender.getCheckedRadioButtonId();
        int selectedAge = rAge.getCheckedRadioButtonId();
        int selectedFood = rFood.getCheckedRadioButtonId();
        int selectedShelter = rShelter.getCheckedRadioButtonId();
        int selectedWater = rWater.getCheckedRadioButtonId();
        int selectedRead = rRead.getCheckedRadioButtonId();
        int selectedWrite = rWrite.getCheckedRadioButtonId();
        int selectedClothes = rClothes.getCheckedRadioButtonId();
        int selectedPhone = rPhone.getCheckedRadioButtonId();
        int selectedHurt = rHurt.getCheckedRadioButtonId();
        int selectedJob = rJob.getCheckedRadioButtonId();
        int selectedJacket = rJacket.getCheckedRadioButtonId();
        int selectedBlankets = rBlankets.getCheckedRadioButtonId();
        int selectedBed = rBed.getCheckedRadioButtonId();

        btnCity = (RadioButton) findViewById(selectedCity);
        btnGender = (RadioButton) findViewById(selectedGender);
        btnAge = (RadioButton) findViewById(selectedAge);
        btnFood = (RadioButton) findViewById(selectedFood);
        btnShelter = (RadioButton) findViewById(selectedShelter);
        btnWater = (RadioButton) findViewById(selectedWater);
        btnRead = (RadioButton) findViewById(selectedRead);
        btnWrite = (RadioButton) findViewById(selectedWrite);
        btnClothes = (RadioButton) findViewById(selectedClothes);
        btnPhone = (RadioButton) findViewById(selectedPhone);
        btnHurt = (RadioButton) findViewById(selectedHurt);
        btnJob = (RadioButton) findViewById(selectedJob);
        btnJacket = (RadioButton) findViewById(selectedJacket);
        btnBlankets = (RadioButton) findViewById(selectedBlankets);
        btnBed = (RadioButton) findViewById(selectedBed);


        String answerCity;
        String answerAge;

        if (btnCity.getText().toString().equals("Other")){
            answerCity = cityText.getText().toString();
        } else {
            answerCity = btnCity.getText().toString();
        }

        if (btnAge.getText().toString().equals("Other")){
            answerAge = ageText.getText().toString();
        } else {
            answerAge = btnAge.getText().toString();
        }

        String answerGender = btnGender.getText().toString();
        String answerFood = btnFood.getText().toString();
        String answerShelter = btnShelter.getText().toString();
        String answerWater = btnWater.getText().toString();
        String answerRead = btnRead.getText().toString();
        String answerWrite = btnWater.getText().toString();
        String answerClothes = btnClothes.getText().toString();
        String answerPhone = btnPhone.getText().toString();
        String answerHurt = btnHurt.getText().toString();
        String answerJob = btnJob.getText().toString();
        String answerJacket = btnJacket.getText().toString();
        String answerBlankets = btnBlankets.getText().toString();
        String answerBed = btnBed.getText().toString();


        SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.putString("city", answerCity);
        editor.putString("water", answerWater);
        editor.putString("age", answerAge);
        editor.putString("gender", answerGender);
        editor.putString("food", answerFood);
        editor.putString("shelter", answerShelter);
        editor.putString("read", answerRead);
        editor.putString("write", answerWrite);
        editor.putString("clothes", answerClothes);
        editor.putString("phone", answerPhone);
        editor.putString("hurt", answerHurt);
        editor.putString("job", answerJob);
        editor.putString("jacket", answerJacket);
        editor.putString("blankets", answerBlankets);
        editor.putString("bed", answerBed);
        editor.apply();


        /*String insertSQL = "INSERT INTO quanda \n" +
                "(city, gender, age, food, shelter, water, read, write, clothes, phone, hurt, job, jacket, blankets, bed)\n" +
                "VALUES \n" +
                "(?, ?, ?, ?);";

        //using the same method execsql for inserting values
        //this time it has two parameters
        //first is the sql string and second is the parameters that is to be binded with the query
        mDatabase.execSQL(insertSQL, new String[]{answerCity, answerGender, answerAge, answerFood, answerShelter, answerWater, answerRead, answerWrite, answerClothes, answerPhone, answerHurt, answerJob, answerJacket, answerBlankets, answerBed});
    */
    }


    public void showDetails(){
        String city = "";
        String water = "";
        String age = "";
        String gender = "";
        String food = "";
        String shelter = "";
        String read = "";
        String write = "";
        String clothes = "";
        String phone = "";
        String hurt = "";
        String job = "";
        String jacket = "";
        String blankets = "";
        String bed = "";


        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
            city = prefs.getString("city", "No city defined");//"No name defined" is the default value.
            water = prefs.getString("water", "Not defined");
            age = prefs.getString("age", "Not defined");
            gender = prefs.getString("gender", "Not defined");
            food = prefs.getString("food", "Not defined");
            shelter = prefs.getString("shelter", "Not defined");
            read = prefs.getString("read", "Not defined");
            write = prefs.getString("write", "Not defined");
            clothes = prefs.getString("clothes", "Not defined");
            phone = prefs.getString("phone", "Not defined");
            hurt = prefs.getString("hurt", "Not defined");
            job = prefs.getString("job", "Not defined");
            jacket = prefs.getString("jacket", "Not defined");
            blankets = prefs.getString("blankets", "Not defined");
            bed = prefs.getString("bed", "Not defined");

            //testing to see if sharedpref is working
        tv1.setText(city);
        tv2.setText(water);


    }

}
