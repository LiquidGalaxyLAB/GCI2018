package com.example.android.hapis_questionnaire;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;

public class PieChart extends Activity {

    static int satisfied;
    static int unsatisfied;

    private static int[] COLORS = new int[] {Color.BLUE,Color.MAGENTA};

    private static int[] VALUES;

    private static String[] NAME_LIST = new String[] { "Satisfied", "Unsatisfied" };

    private CategorySeries mSeries = new CategorySeries("Basic Needs");

    private DefaultRenderer mRenderer = new DefaultRenderer();

    private GraphicalView mChartView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pie_chart);

        String city = "";
        String water = "";
        String age = "";
        String gender = "";
        String food = "";
        String shelter = "";
        String read = "";
        String write = "";
        String clothes = "";
        String phone = "";
        String hurt = "";
        String job = "";
        String jacket = "";
        String blankets = "";
        String bed = "";

        SharedPreferences prefs = getSharedPreferences("MyPrefsFile", MODE_PRIVATE);
        city = prefs.getString("city", "No city defined");//"No name defined" is the default value.
        water = prefs.getString("water", "Not defined");
        age = prefs.getString("age", "Not defined");
        gender = prefs.getString("gender", "Not defined");
        food = prefs.getString("food", "Not defined");
        shelter = prefs.getString("shelter", "Not defined");
        read = prefs.getString("read", "Not defined");
        write = prefs.getString("write", "Not defined");
        clothes = prefs.getString("clothes", "Not defined");
        phone = prefs.getString("phone", "Not defined");
        hurt = prefs.getString("hurt", "Not defined");
        job = prefs.getString("job", "Not defined");
        jacket = prefs.getString("jacket", "Not defined");
        blankets = prefs.getString("blankets", "Not defined");
        bed = prefs.getString("bed", "Not defined");

        satisfied = 0;
        unsatisfied = 0;

        if (water.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (food.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (shelter.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (read.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (write.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (clothes.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (phone.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (hurt.equals("Yes")){
            unsatisfied = unsatisfied + 1;
        } else {
            satisfied = satisfied + 1;
        }

        if (jacket.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (blankets.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }

        if (bed.equals("Yes")){
            satisfied = satisfied + 1;
        } else {
            unsatisfied = unsatisfied + 1;
        }


        VALUES = new int[] { satisfied, unsatisfied };


        mRenderer.setChartTitle("Basic Human Needs");
        mRenderer.setApplyBackgroundColor(true);
        mRenderer.setBackgroundColor(Color.argb(100, 50, 50, 50));
        mRenderer.setChartTitleTextSize(90);
        mRenderer.setLabelsTextSize(30);
        mRenderer.setLegendTextSize(30);
        mRenderer.setMargins(new int[] { 20, 30, 15, 0 });
        mRenderer.setZoomButtonsVisible(true);
        mRenderer.setStartAngle(90);

        for (int i = 0; i < VALUES.length; i++) {
            mSeries.add(NAME_LIST[i] + " " + VALUES[i], VALUES[i]);
            SimpleSeriesRenderer renderer = new SimpleSeriesRenderer();
            renderer.setColor(COLORS[(mSeries.getItemCount() - 1) % COLORS.length]);
            mRenderer.addSeriesRenderer(renderer);
        }

        if (mChartView != null) {
            mChartView.repaint();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mChartView == null) {
            LinearLayout layout = (LinearLayout) findViewById(R.id.chart);
            mChartView = ChartFactory.getPieChartView(this, mSeries, mRenderer);
            mRenderer.setClickEnabled(true);
            mRenderer.setSelectableBuffer(10);

            /*mChartView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SeriesSelection seriesSelection = mChartView.getCurrentSeriesAndPoint();

                    if (seriesSelection == null) {
                        Toast.makeText(PieChart.this,"No chart element was clicked",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(PieChart.this,"Chart element data point index "+ (seriesSelection.getPointIndex()+1) + " was clicked" + " point value="+ seriesSelection.getValue(), Toast.LENGTH_SHORT).show();
                    }
                }
            });

            mChartView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    SeriesSelection seriesSelection = mChartView.getCurrentSeriesAndPoint();
                    if (seriesSelection == null) {
                        Toast.makeText(PieChart.this,"No chart element was long pressed", Toast.LENGTH_SHORT);
                        return false;
                    }
                    else {
                        Toast.makeText(PieChart.this,"Chart element data point index "+ seriesSelection.getPointIndex()+ " was long pressed",Toast.LENGTH_SHORT);
                        return true;
                    }
                }
            });*/
            layout.addView(mChartView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        }
        else {
            mChartView.repaint();
        }
    }
}