//getting pages elements
var userPic = document.getElementById('pic');
var userName = document.getElementById('nome');
var signInBtn = document.getElementById('login-button');
var signOutBtn = document.getElementById('logout-button');
var collection = document.getElementById('myout');
var send = document.getElementById("send-button");
var info = document.getElementById("country_in");
var inn = document.getElementById("in");
var out = document.getElementById('out');
var countriesBtn = document.getElementById('toggle_countries');
var countriesDiv = document.getElementById('countries_div');

//adding listeners
countriesBtn.addEventListener('click', toggleCountries);
signInBtn.addEventListener('click',logIn);
signOutBtn.addEventListener('click',logOut);
//send.addEventListener("click", saveCountry);
//calling functions that are listeners
initFirebaseAuth();

gettingCountry();


var config = {
    apiKey: "AIzaSyARkh53ndcbKBbkxZFsSm1uibXtVhlQ4yA",
    authDomain: "liquid-galaxy-sample.firebaseapp.com",
    databaseURL: "https://liquid-galaxy-sample.firebaseio.com",
    projectId: "liquid-galaxy-sample",
    storageBucket: "liquid-galaxy-sample.appspot.com",
    messagingSenderId: "653196986372"
  };
     
  firebase.initializeApp(config);
  


function logIn(){
    var provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithRedirect(provider);
    firebase.auth().getRedirectResult().then(function(result) {
    if (result.credential) {
      // This gives you a Google Access Token. You can use it to access the Google API.
      var token = result.credential.accessToken;
      // ...
    }
    // The signed-in user info.
    var user = result.user;
    }).catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    // The email of the user's account used.
    var email = error.email;
    // The firebase.auth.AuthCredential type that was used.
    var credential = error.credential;
    // ...
  });
}


function logOut(){
  firebase.auth().signOut().then(function() {
    // Sign-out successful.
  }).catch(function(error) {
    // An error happened.
  });
}


function toggleCountries(){
  if (countriesDiv.style.display === "none") {
        countriesDiv.style.display = "block";
    } else {
        countriesDiv.style.display = "none";
    }
}

function initApp(){

  firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    // User is signed in.
    document.getElementById("out").style.display = "block";
    document.getElementById("in").style.display = "none";
    var user = firebase.auth().currentUser;
    if(user != null){
      var email_id = user.email;
      var name = user.displayName;
      var photoURL = user.photoURL;
      document.getElementById("welcome_p").innerHTML = "Welcome " + name;
      document.getElementById('prof_pic').src= "" + photoURL;
    }
  } else {  // No user is signed in.
    document.getElementById("out").style.display = "none";
    document.getElementById("in").style.display = "block";
  }
});
}


function initFirebaseAuth() {
  // Listen to auth state changes.
  //firebase.auth().onAuthStateChanged(authStateObserver);
  initApp();
}

// Returns the signed-in user's profile Pic URL.
function getProfilePicUrl() {
  return firebase.auth().currentUser.photoURL;
}

// Returns the signed-in user's display name.
function getUserName() {
  return firebase.auth().currentUser.displayName;
}

// Returns true if a user is signed-in.
function isUserSignedIn() {
  return !!firebase.auth().currentUser;
}

function displayMessage(text) {
  var container = document.createElement('li');
  container.setAttribute('id', text);
  container.setAttribute('class',"collection-item");
  collection.appendChild(container);
  container.innerText = text;
}

window.onload = function(){    
  firebase.initializeApp(config);
  initApp();
  var database = firebase.database();
}


function saveCountry(){
  if (isUserSignedIn()){
    firebase.database().ref('Countries/' + info.value).set(
            {
                submitted_by : getUserName()
            }
        )
    window.alert(info.value + " was saved! Thanks for contributing!");
    info.value="";
  } else {
	   window.alert("Log in to add to our list!");
  }
}

function gettingCountry(){
    var rootRef = firebase.database().ref();
    var countryRef = rootRef.child("Countries");
    countryRef.once("value", function(snapshot) {
      snapshot.forEach(function(child) {
        displayMessage(child.key);
      });
    });
}


