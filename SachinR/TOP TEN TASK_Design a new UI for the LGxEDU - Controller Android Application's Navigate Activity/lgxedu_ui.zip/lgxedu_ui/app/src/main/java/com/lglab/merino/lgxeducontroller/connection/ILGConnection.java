package com.lglab.merino.lgxeducontroller.connection;

public interface ILGConnection {
    void setStatus(short status);
}
