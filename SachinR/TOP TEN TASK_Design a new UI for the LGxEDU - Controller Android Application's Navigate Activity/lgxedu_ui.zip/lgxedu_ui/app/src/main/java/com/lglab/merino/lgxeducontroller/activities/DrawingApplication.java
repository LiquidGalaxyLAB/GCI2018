package com.lglab.merino.lgxeducontroller.activities;

import android.app.Application;

/**
 * @author mimming
 * @since 12/5/14.
 *
 * Initialize Firebase with the application context. This must happen before the client is used.
 */
public class DrawingApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
